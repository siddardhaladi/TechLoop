export interface Course {
  courseId: number;
  title: string;
  description: string;
  contentURL: string;
  instructorID?: number;
}
