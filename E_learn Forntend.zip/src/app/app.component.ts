// import { Component } from '@angular/core';
// import { RouterOutlet } from '@angular/router';
// import { HomeComponent } from './Homepage/Homepage.component';

// @Component({
//   selector: 'app-root',
//   imports: [RouterOutlet, HomeComponent],
//   templateUrl: './app.component.html',
//   styleUrl: './app.component.css'
// })
// export class AppComponent {
//   title = 'myapp';
// }
import {Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Router, RouterModule, RouterOutlet } from '@angular/router';
import { LoginComponent } from './Login.component';
import { HomeComponent } from "./Homepage/Homepage.component";
import { CourseService } from './course.service';
import { CoursesComponent } from './course/course.component';
 
 
@Component({
  selector: 'app-root',
  standalone:true,
  imports: [CommonModule,FormsModule, RouterModule,CoursesComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'e_lproject';
}
