
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './Homepage/Homepage.component';
import { AppComponent } from './app.component';
import { CoursesComponent } from './course/course.component';
import { CoursedetailComponent } from './coursedetail/coursedetails.component';
import { LoginComponent } from './Login.component';
import { AddCourseComponent } from './addcourse/addcourse.component';
import { InstructorCoursesComponent } from './instructorcourses/instructorcourses.component';
import { MyCoursesComponent } from './mycourses/mycourses.component';
import { CoursesearchComponent } from './coursesearch/coursesearch.component';
import { QuestionFormComponent } from './question-form/question-form.component';
import { QuestionListComponent } from './question-list/question-list.component';
import { ContactComponent } from './contact/contact.component';





export const routes: Routes = [
{ path: '', component:LoginComponent },
{ path:'Homepage', component:HomeComponent},
{ path: 'add-course', component:AddCourseComponent},
{ path: 'course', component:CoursesComponent},
{ path: 'mycourse', component:MyCoursesComponent},
{ path: 'coursedetails/:courseId', component:CoursedetailComponent},
{ path: 'instructorcourses', component:InstructorCoursesComponent},
{ path: 'coursesearch', component:CoursesearchComponent},
{ path: 'question-form/:courseId', component:QuestionFormComponent},
{ path: 'question-list/:assessmentId', component:QuestionListComponent},
{path:'contact', component: ContactComponent}
];

export class AppRoutingModule { }
