// import { Component } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { Router, RouterOutlet } from '@angular/router';
// import { CoursedetailComponent } from '../coursedetail/coursedetails.component';

// @Component({
//   selector: 'app-home',
//   imports:[CommonModule],
//   templateUrl: './homepage.component.html',
//   styleUrls: ['./homepage.component.css']
// })
// export class HomeComponent {
//   title = 'e-learning-portal';

//   courses = [
//     {
//       id:1,
//       title: 'Introduction to Programming',
//       description: 'Learn the basics of programming with this introductory course.',
//       image: 'https://tse2.mm.bing.net/th/id/OIP.FlkPlCGqN4yYcKGABBPI6wHaEK?w=310&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7'
//     },
//     {
//       id:2,
//       title: 'Web Development',
//       description: 'Build modern web applications using HTML, CSS, and JavaScript.',
//       image: 'https://tse3.mm.bing.net/th/id/OIP.Jg35DTU8xEFi-BbUaql9CQHaEI?w=299&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7'
//     },
//     {
//       id:3,
//       title: 'Data Science',
//       description: 'Explore the world of data science and learn how to analyze data.',
//       image: 'https://tse3.mm.bing.net/th/id/OIP.qPCItcMBgEzizghD3XZMAQHaEK?w=287&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7'
//     },
//     {
//       id:4,
//       title: 'Machine Learning',
//       description: 'Understand the fundamentals of machine learning and its applications.',
//       image: ''
//     },
//     {
//       id:5,
//       title: 'Cyber Security',
//       description: 'Learn how to protect systems and networks from cyber threats.',
//       image: ''
//     },
//     {
//       title: 'Digital Marketing',
//       description: 'Master the art of digital marketing and online advertising.',
//       image: ''
//     },
//     {
//       title: 'Graphic Design',
//       description: 'Develop your skills in graphic design and visual communication.',
//       image: 'https://tse3.mm.bing.net/th/id/OIP.DuyeLb7lpU2BDRc5T7Ta5AHaEc?w=281&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7'
//     },
//     {
//       title: 'Project Management',
//       description: 'Learn the principles of project management and how to apply them.',
//       image: ''
//     },
//     {
//       title: 'Artificial Intelligence',
//       description: 'Explore the world of AI and its impact on various industries.',
//       image: 'https://tse1.mm.bing.net/th/id/OIP.xEFUKS_9p7UHClAwqVRBTAHaEo?w=286&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7'
//     },
//     // {
//     //   title: 'Blockchain Technology',
//     //   description: 'Understand the basics of blockchain and its potential applications.',
//     //   image: 'assets/blockchain.jpg'
//     // },
//     // {
//     //   title: 'Cloud Computing',
//     //   description: 'Learn about cloud computing and how to leverage it for business.',
//     //   image: 'assets/cloud-computing.jpg'
//     // },
//     // {
//     //   title: 'Mobile App Development',
//     //   description: 'Create mobile applications for Android and iOS platforms.',
//     //   image: 'assets/mobile-app-development.jpg'
//     // }
//   ];

//   filteredCourses = this.courses;
//   selectedCourse: any = null;

//   onSearch(event: any) {
//     const searchTerm = event.target.value.toLowerCase();
//     this.filteredCourses = this.courses.filter(course =>
//       course.title.toLowerCase().includes(searchTerm)
//     );
//   }

//     constructor(private router: Router) {}

//     
// viewCourse(id: number | undefined): void {
//     if (id !== undefined) {
//       this.router.navigate(['/course', id]);
//     } else {
//       console.error('Course ID is undefined');
//     }
//   }

  
  
//   enroll() {
//     alert('Enrollment process will start soon!');
//   }

  
// }
// import { Component } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { Router, RouterOutlet } from '@angular/router';
// import { CoursedetailComponent } from '../coursedetail/coursedetails.component';

// @Component({
//   selector: 'app-home',
//   imports: [CommonModule],
//   templateUrl: './homepage.component.html',
//   styleUrls: ['./homepage.component.css']
// })
// export class HomeComponent {
//   title = 'e-learning-portal';

//   constructor(private router: Router) {}

//   enroll() {
//     alert('Enrollment process will start soon!');
//   }
  
// navigateTo(path: string): void {
//       this.router.navigate([path]);
//     }
  
// }
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { NavbarComponent } from '../navbar/navbar.component';
import { CoursesearchComponent } from "../coursesearch/coursesearch.component";
 
@Component({
  selector: 'app-homepage',
  standalone:true,
  imports: [FormsModule, CommonModule, NavbarComponent, CoursesearchComponent],
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomeComponent {
  courses = [
    // { image: 'assets/images/course1.jpg', title: 'Course 1', description: 'Description for Course 1' },
    // { image: 'assets/images/course2.jpg', title: 'Course 2', description: 'Description for Course 2' },
    // { image: 'assets/images/course3.jpg', title: 'Course 3', description: 'Description for Course 3' }
  ];
  selectedCourse: any;
  searchQuery: any;
  
constructor(private router: Router) {}
  enroll(){
        this.router.navigate(['/course']);

  }

}