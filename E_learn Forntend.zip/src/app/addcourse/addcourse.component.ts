// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-addcourse',
//   imports: [],
//   templateUrl: './addcourse.component.html',
//   styleUrl: './addcourse.component.css'
// })
// export class AddcourseComponent {

// }
import { Component } from '@angular/core';
import { AddCourseService } from './addcourse.service';
import { AddCourse } from './addcourse.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router,RouterOutlet } from '@angular/router';
import { NavbarComponent } from "../navbar/navbar.component";
import { AuthService } from '../Authservice';

@Component({
  selector: 'app-addcourse',
  imports: [CommonModule, FormsModule, RouterOutlet, NavbarComponent],
  templateUrl: './addcourse.component.html',
  styleUrls: ['./addcourse.component.css']
})
export class AddCourseComponent {
  constructor(private addCourseService: AddCourseService,private router:Router,private authservice:AuthService) {}

  addcourse: AddCourse = {
    title: '',
    description: '',
    contentURL: '',
    instructorId:1,
  };

  // constructor(private addCourseService: AddCourseService,private router:Router,private authservice:AuthService) {}

  AddCourse() {
    this.addCourseService.AddCourse(this.addcourse).subscribe(response => {
      console.log('AddCourse added:', response);
      this.router.navigate(['/course']); // Navigate to the courses list

      // Optionally, navigate to the addcourses list or reset the form
    });
  }
  ngOnInit(): void {
   this.authservice.getInstructorIdFromToken().subscribe(
        (instructorId) => {
          this.addcourse.instructorId = instructorId;
        },
        (error) => {
          console.error('Error fetching instructor ID:', error);
        }
      );
}
  
}

