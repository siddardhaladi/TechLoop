export interface AddCourse {
    title: string;
    description: string;
    contentURL: string;
    instructorId:number;
  }
  